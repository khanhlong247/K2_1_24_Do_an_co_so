

<?php $__env->startSection('title', 'Quản lý Lịch Hẹn'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h1 class="text-center mb-4" style="font-family: 'Poppins', sans-serif;">Quản lý Lịch Hẹn</h1>

    <!-- Form tìm kiếm lịch hẹn -->
    <form method="GET" action="<?php echo e(route('admin.appointments.index')); ?>" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Tìm kiếm lịch hẹn..."
                value="<?php echo e($search ?? ''); ?>">
            <button type="submit" class="btn btn-primary">Tìm kiếm</button>
        </div>
    </form>

    <!-- Form thêm/sửa lịch hẹn -->
    <?php if($editAppointment): ?>
    <h3 class="mb-3">Sửa Lịch Hẹn</h3>
    <form method="POST" action="<?php echo e(route('admin.appointments.update', $editAppointment->id)); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="POST">

        <?php else: ?>
        <h3 class="mb-3">Thêm Lịch Hẹn</h3>
        <form method="POST" action="<?php echo e(route('admin.appointments.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php endif; ?>

            <div class="row">
                <!-- Dịch vụ -->
                <div class="col-md-4 mb-2">
                    <label for="specialty" class="form-label">Dịch Vụ</label>
                    <select name="specialty" id="specialty" class="form-control" required>
                        <option value="">-- Chọn Dịch Vụ --</option>
                        <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($specialty); ?>"
                            <?php echo e(isset($editAppointment) && $editAppointment->specialty == $specialty ? 'selected' : ''); ?>>
                            <?php echo e($specialty); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-4 mb-2">
                    <label for="doctor_id" class="form-label">Chọn Bác Sĩ</label>
                    <select name="doctor_id" id="doctor_id" class="form-control" required>
                        <option value="">-- Chọn mục Dịch Vụ trước --</option>
                    </select>
                </div>

                <!-- Script AJAX -->
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script>
                $(document).ready(function() {
                    $('#specialty').change(function() {
                        var specialty = $(this).val();
                        $('#doctor_id').html(
                            '<option value="">-- Đang tải danh sách bác sĩ... --</option>');

                        if (specialty) {
                            $.ajax({
                                url: '/get-doctors-by-specialty',
                                type: 'GET',
                                data: {
                                    specialty: specialty
                                },
                                success: function(data) {
                                    $('#doctor_id').html(
                                        '<option value="">-- Chọn Bác Sĩ --</option>');
                                    $.each(data, function(index, doctor) {
                                        $('#doctor_id').append('<option value="' +
                                            doctor.id + '">' + doctor.name +
                                            '</option>');
                                    });
                                },
                                error: function() {
                                    $('#doctor_id').html(
                                        '<option value="">-- Không có bác sĩ nào --</option>'
                                    );
                                }
                            });
                        } else {
                            $('#doctor_id').html(
                                '<option value="">-- Chọn mục Dịch Vụ trước --</option>');
                        }
                    });
                });
                </script>

                <!-- Ngày hẹn -->
                <div class="col-md-4 mb-2">
                    <label for="appointment_date" class="form-label">Ngày hẹn</label>
                    <input type="date" name="appointment_date" id="appointment_date" class="form-control"
                        value="<?php echo e($editAppointment->appointment_date ?? ''); ?>" required>
                </div>

                <!-- Tên bệnh nhân -->
                <div class="col-md-4 mb-2">
                    <label for="name" class="form-label">Tên bệnh nhân</label>
                    <input type="text" name="name" id="name" class="form-control"
                        value="<?php echo e($editAppointment->name ?? ''); ?>" required>
                </div>

                <!-- Email -->
                <div class="col-md-4 mb-2">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" id="email" class="form-control"
                        value="<?php echo e($editAppointment->email ?? ''); ?>" required>
                </div>

                <!-- Số điện thoại -->
                <div class="col-md-4 mb-2">
                    <label for="phone" class="form-label">Số điện thoại</label>
                    <input type="text" name="phone" id="phone" class="form-control"
                        value="<?php echo e($editAppointment->phone ?? ''); ?>" required>
                </div>

                <!-- Tuổi -->
                <div class="col-md-4 mb-2">
                    <label for="age" class="form-label">Tuổi</label>
                    <input type="number" name="age" id="age" class="form-control"
                        value="<?php echo e($editAppointment->age ?? ''); ?>" required>
                </div>

                <!-- CCCD -->
                <div class="col-md-4 mb-2">
                    <label for="cccd" class="form-label">CCCD</label>
                    <input type="text" name="cccd" id="cccd" class="form-control"
                        value="<?php echo e($editAppointment->cccd ?? ''); ?>" required>
                </div>

                <!-- Mô tả -->
                <div class="col-md-4 mb-2">
                    <label for="description" class="form-label">Mô tả</label>
                    <textarea name="description" id="description"
                        class="form-control"><?php echo e($editAppointment->description ?? ''); ?></textarea>
                </div>

                <!-- Nút Gửi -->
                <div class="col-md-4 mb-2">
                    <button type="submit"
                        class="btn <?php echo e(isset($editAppointment) ? 'btn-warning' : 'btn-success'); ?> w-100">
                        <?php echo e(isset($editAppointment) ? 'Lưu Thay Đổi' : 'Thêm Lịch Hẹn'); ?>

                    </button>
                </div>
            </div>
        </form>

        <!-- Danh sách lịch hẹn -->
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>#</th>

                    <th>Bác Sĩ</th>
                    <th>Bệnh Nhân</th>
                    <th>Email</th>
                    <th>Mô Tả</th>
                    <th>Điện Thoại</th>
                    <th>Ngày Hẹn</th>
                    <th>Trạng Thái</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>

                    <td><?php echo e(optional($appointment->doctor)->name ?? 'Không xác định'); ?></td>
                    <td><?php echo e($appointment->name); ?></td>
                    <td><?php echo e($appointment->email); ?></td>
                    <td><?php echo e($appointment->description); ?></td>
                    <td><?php echo e($appointment->phone); ?></td>
                    <td><?php echo e($appointment->appointment_date); ?></td>
                    <td>
                        <?php if($appointment->status === 'pending'): ?>
                        <span class="badge bg-warning">Chờ duyệt</span>
                        <?php elseif($appointment->status === 'approved'): ?>
                        <span class="badge bg-success">Đã duyệt</span>
                        <?php else: ?>
                        <span class="badge bg-danger">Đã từ chối</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <!-- Nút Duyệt -->
                        <form method="POST" action="<?php echo e(route('admin.appointments.approve', $appointment->id)); ?>"
                            class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit" class="btn btn-success btn-sm">Duyệt</button>
                        </form>

                        <!-- Nút Từ chối -->
                        <form method="POST" action="<?php echo e(route('admin.appointments.reject', $appointment->id)); ?>"
                            class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit" class="btn btn-dark btn-sm">Từ chối</button>
                        </form>

                        <!-- Nút Sửa -->
                        <a href="<?php echo e(route('admin.appointments.index', ['edit_id' => $appointment->id])); ?>"
                            class="btn btn-warning btn-sm">Sửa</a>

                        <!-- Nút Xóa -->
                        <form method="POST" action="<?php echo e(route('admin.appointments.destroy', $appointment->id)); ?>"
                            class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Bạn có chắc chắn muốn xóa lịch hẹn này?')">Xóa</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Visual Studio Code\DoAnCoSo\dermatology_clinic\Quan_Ly_Phong_Kham_Da_Lieu\resources\views/role/manageappointments.blade.php ENDPATH**/ ?>